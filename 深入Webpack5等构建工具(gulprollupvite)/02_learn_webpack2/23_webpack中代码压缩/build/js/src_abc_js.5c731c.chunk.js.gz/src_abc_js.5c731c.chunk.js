(self.webpackChunkwebpack_devserver=self.webpackChunkwebpack_devserver||[]).push([["src_abc_js"],{"./src/abc.js":
/*!********************!*\
  !*** ./src/abc.js ***!
  \********************/(e,c,a)=>{"use strict";function abc(){return"abc"}a.r(c),a.d(c,{abc:()=>abc});var d=document.createElement("div");d.className="title",document.body.appendChild(d);var r=document.createElement("h2");document.body.appendChild(r)}}]);
//# sourceMappingURL=src_abc_js.5c731c.chunk.js.map